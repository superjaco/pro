package proposto03e;

import java.util.ArrayList;

public class Calculos {

    static int cantos(ArrayList<Integer> lista) {
        return lista.size();
    }

    static int max(ArrayList<Integer> lista) {
        int max = 0;
        if (cantos(lista) > 0) {
            max = lista.get(0);
            for (int i = 1; i < cantos(lista); i++) {
                if (lista.get(i) > max) {
                    max = lista.get(i);
                }
            }
        }
        return max;
    }

    static int min(ArrayList<Integer> lista) {
        int min = 0;
        if (cantos(lista) > 0) {
            min = lista.get(0);
            for (int i = 1; i < cantos(lista); i++) {
                if (lista.get(i) < min) {
                    min = lista.get(i);
                }
            }
        }
        return min;
    }

    static float media(ArrayList<Integer> lista) {
        float media = 0;
        int suma = 0;
        if (cantos(lista) > 0) {
            for (Integer n : lista) {
                suma += n;
            }
            media = (float)suma / cantos(lista);
        }
        return media;
    }

}
