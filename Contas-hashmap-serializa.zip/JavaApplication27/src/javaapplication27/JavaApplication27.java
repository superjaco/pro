package javaapplication27;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;

public class JavaApplication27 {

    public static void main(String[] args) {
        //lectura inicial
        HashMap<String, ContaBancaria> contas = ler();

        //tratamento da información
        //  visualización das contas que estaban almacenadas
        for (String iban : contas.keySet()) {
            System.out.println(contas.get(iban));
        }
        //  creación dunha nova conta
        contas.put("ES" + Math.random() * 1000, new ContaBancaria("abc", "abc", "abc", 1000));

        //almacenamento final como obxecto
        gardar(contas);
        //almacenamento final como texto
        gardarListado(contas);
    }

    public static void gardar(HashMap<String, ContaBancaria> contas) {
        try {
            //abrir
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("datos.dat"));
            //escribir
            oos.writeObject(contas);
            //pechar
            oos.close();
        } catch (FileNotFoundException ex) {
            System.out.println("Non existe o ficheiro");
        } catch (IOException ex) {
            System.out.println("Non foi posible escribir no ficheiro");
        }
    }

    public static HashMap<String, ContaBancaria> ler() {
        try {
            //abrir
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream("datos.dat"));
            //ler
            HashMap<String, ContaBancaria> contas = (HashMap<String, ContaBancaria>) ois.readObject();
            //pechar
            ois.close();
            return contas;
        } catch (FileNotFoundException ex) {
            System.out.println("Non existe o ficheiro");
        } catch (IOException ex) {
            System.out.println("Non foi posible ler do ficheiro");
        } catch (ClassNotFoundException ex) {
            System.out.println("A clase do obxecto non é correcta");
        }
        return new HashMap<String, ContaBancaria>();
    }

    public static void gardarListado(HashMap<String, ContaBancaria> contas) {
        try {
            //abrir un ficheiro de texto
            FileWriter fw = new FileWriter("listado.txt");
            //escribir
            for (String iban : contas.keySet()) {
                fw.write(contas.get(iban).toString() + "\n");
            }
            //pechar
            fw.close();
        } catch (IOException ex) {
            System.out.println("Non foi posible esribir no ficheiro");
        }
    }
}
