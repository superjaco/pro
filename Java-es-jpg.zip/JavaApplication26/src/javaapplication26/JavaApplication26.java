package javaapplication26;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class JavaApplication26 {

    public static void main(String[] args) {
        File carpeta = new File(".");
        byte[] buffer = new byte[2];
        int lidos;
        
        if (carpeta.isDirectory()) {
            for (File f : carpeta.listFiles()) {
                // ver se o ficheiro contén ou non unha imaxe JPG
                // mirando os 2 primeiros bytes
                if(f.isFile()) {
                    try {
                        //abrir
                        FileInputStream fis = new FileInputStream(f);
                        //ler
                        lidos = fis.read(buffer);
                        System.out.print("o ficheiro " + f.getName() + " ");
                        if (buffer[0]==(byte)0xFF && buffer[1]==(byte)0xD8) {
                            System.out.println("O ficheiro é JPG");
                        } else {
                            System.out.println("O ficheiro non é JPG");
                        }
                        //pechar
                        fis.close();
                    } catch (FileNotFoundException ex) {
                        System.out.println("Non existe o ficheiro");
                    } catch (IOException ex) {
                        System.out.println("Non foi posible ler");
                    }
                }
            }
        }
    }

}
