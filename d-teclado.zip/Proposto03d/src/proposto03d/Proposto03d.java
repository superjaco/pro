package proposto03d;

import java.util.ArrayList;
import java.util.Scanner;

public class Proposto03d {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        ArrayList<Integer> numeros = new ArrayList<>();
        int numero;
        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;
        int suma = 0;

        while (true) {
            System.out.println("Introduce un número (0 para rematar)");
            try {
                numero = Integer.parseInt(teclado.nextLine());
                if (numero == 0) {
                    break;
                } else {
                    numeros.add(numero);
                }
            } catch (NumberFormatException ex) {
                System.out.println("Introduce un número enteiro");
            }
        }

        if (numeros.size() > 0) {
            System.out.println("Hai " + Calculos.cantos(numeros) + " datos");
            System.out.println("Menor: " + Calculos.min(numeros));
            System.out.println("Maior: " + Calculos.max(numeros));
            System.out.println("Media: " + Calculos.media(numeros));
        }

    }

}
