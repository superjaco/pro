
package javaapplication28;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class JavaApplication28 {

    public static void main(String[] args) {
        try {
            // conectar
            Connection con = DriverManager.getConnection(
                    "jdbc:mariadb://localhost:3306/clientes?user=root&password=root"
            );
            System.out.println("A conexión non tivo ningún problema");
            
            Statement st = con.createStatement();
            //st.executeQuery("INSERT INTO novos VALUES (4, 'Celia')");
            st.executeQuery("DELETE FROM NOVOS WHERE NOME='Celia'");
            
            
        } catch (SQLException ex) {
            System.out.println("Non foi posible a conexión");
            System.out.println(ex.getMessage());
        }
    }
    
}
