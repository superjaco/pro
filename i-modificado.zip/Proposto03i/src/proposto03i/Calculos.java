package proposto03i;

public class Calculos {

    int cantos;
    int max;
    int min;
    float media;

    public Calculos(int cantos, int max, int min, float media) {
        this.cantos = cantos;
        this.max = max;
        this.min = min;
        this.media = media;
    }

}
