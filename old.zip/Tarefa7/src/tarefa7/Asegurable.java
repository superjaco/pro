
package tarefa7;


public interface Asegurable {
    // listado de métodos (cabeceiras sen código)
    public void buscarSeguro();
    public void gardarSeguro();
    
}
