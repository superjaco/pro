package tarefa7;

import javax.swing.JFrame;

public class Tarefa7 {

    public static void main(String[] args) {
        Vehiculo v; // 4 datos
        VehiculoDePasaxeiros vp; // 4 datos + pasaxeiros
        VehiculoDeCarga vc; // 4 datos + carga

        Persoa p = new Persoa("3265656Y","Alberto","Rúa Real");
        
        
        vp = new VehiculoDePasaxeiros(5,"1234ABC",p, null, 3000);
        
        

        System.out.println(vp.toString());

    }

}
