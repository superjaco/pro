package tarefa7;

import java.time.LocalDate;

public class VehiculoDeCarga extends Vehiculo {

    private int carga;

    public VehiculoDeCarga(int carga, String matricula, Persoa propietario, LocalDate dataDeMatriculacion, int peso) {
        super(matricula, propietario, dataDeMatriculacion, peso);
        this.carga = carga;
    }

    public int getCarga() {
        return carga;
    }

    public void setCarga(int carga) {
        if (carga > 0 && carga < 10000) {
            this.carga = carga;
        }
    }

}
