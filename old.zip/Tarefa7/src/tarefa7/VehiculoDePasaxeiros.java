
package tarefa7;

import java.time.LocalDate;

public class VehiculoDePasaxeiros extends Vehiculo {
    private int pasaxeiros;

    public VehiculoDePasaxeiros(int pasaxeiros, String matricula, Persoa propietario, LocalDate dataDeMatriculacion, int peso) {
        super(matricula, propietario, dataDeMatriculacion, peso);
        this.pasaxeiros = pasaxeiros;
    }

    public int getPasaxeiros() {
        return pasaxeiros;
    }

    public void setPasaxeiros(int pasaxeiros) {
        this.pasaxeiros = pasaxeiros;
    }

    @Override
    public String toString() {
        return "VehiculoDePasaxeiros{" + "pasaxeiros=" + pasaxeiros + '}';
    }

    
}
