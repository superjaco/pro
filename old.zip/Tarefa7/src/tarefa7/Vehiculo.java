package tarefa7;

import java.time.LocalDate;

public class Vehiculo implements Asegurable {
    private String matricula;
    private Persoa propietario;
    private LocalDate dataDeMatriculacion;
    private int peso;

    @Override
    public void gardarSeguro() {
        System.out.println("Estamos gardando seguro para un vehículo");
    }

    @Override
    public void buscarSeguro() {
        System.out.println("Estamos buscando seguro para un vehículo");
    }

    public Vehiculo(String matricula, Persoa propietario, LocalDate dataDeMatriculacion, int peso) {
        this.matricula = matricula;
        Persoa persoaNova = new Persoa(
                propietario.getDni(),
                propietario.getNome(),
                propietario.getEnderezo());
        this.propietario = persoaNova;
        this.dataDeMatriculacion = dataDeMatriculacion;
        this.peso = peso;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public LocalDate getMatriculacion() {
        return dataDeMatriculacion;
    }

    public void setMatriculacion(LocalDate matriculacion) {
        this.dataDeMatriculacion = matriculacion;
    }

    public int getPeso() {
        return peso*1000;
    }

    public void setPeso(int peso) {
        this.peso = peso;
    }

    public Persoa getPropietario() {
        return propietario;
    }

    public void setPropietario(Persoa propietario) {
        this.propietario = propietario;
    }

    @Override
    public String toString() {
        return "Vehiculo{" + "matricula=" + matricula + ", propietario=" + propietario + ", dataDeMatriculacion=" + dataDeMatriculacion + ", peso=" + peso + '}';
    }
   
}