
package tarefa7;


public class Persoa implements Asegurable {
    private String dni;
    private String nome;
    private String enderezo;

    @Override
    public void buscarSeguro() {
        System.out.println("buscando Seguro de persoa");
    }

    @Override
    public void gardarSeguro() {
        System.out.println("gardando Seguro de persoa");
    }



    public Persoa(String dni, String nome, String enderezo) {
        this.dni = dni;
        this.nome = nome;
        this.enderezo = enderezo;
    }

    public String getEnderezo() {
        return enderezo;
    }

    public void setEnderezo(String enderezo) {
        this.enderezo = enderezo;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
}
